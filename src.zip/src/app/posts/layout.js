import React from "react";

const PostsLayout = ({ children }) => {
    return <div className="container mx-auto py-20">{children}</div>
};

export default PostsLayout;
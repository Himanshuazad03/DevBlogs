import { BlogSidebar } from "../../../components/BlogSide.jsx";
import { checkUser } from "../../../src/lib/checkUser";

export default async function AppLayout({ children }) {
  const user = await checkUser();

  return <BlogSidebar user={user}>{children}</BlogSidebar>;
}
